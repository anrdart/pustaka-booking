<h1 align="center">Pustaka Booking</h1>
<h3 align="center">Aplikasi Web dengan Framework Codeigniter</h3>


<p align='center'>Ini adalah aplikasi web yang dibuat berdasarkan modul materi Web Programming II Universitas Bina Sarana Informatika, dengan menggunakan framework Codeigniter 3.</p>

<p align='center'>Projek ini dibuat untuk memenuhi tugas Web Programming II Pertemuan 6 - 12.</p>

<br>
<br>
<h2 align='center'>Terima Kasih:sunglasses:</h2>
